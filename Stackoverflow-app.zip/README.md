# StackOverflow 

## Development Build

please make sure to install latest Angular-cli version.
1. `npm install`
2. `npm start`

browse app on http://localhost:4200/auth/question

else there is dist folder available run node server.js and browse app on http://localhost:3000/auth/question

## Production Build

1. `npm run build`

## Activities Done - 

I have covered below details -

* fetching data over http call
* Visually interactive design to list​questions.
* Design Profile Page, with tags and question-list
* version control
