export const menus = [
    {
        'name': 'Question-page',
        'icon': 'list',
        'link': '/auth/question',
        'open': false,
    }, {
        'name': 'User-Profile',
        'icon': 'account_circle',
        'link': '/auth/user',
        'open': false,
    }
];

