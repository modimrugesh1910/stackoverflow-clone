export const ToolbarHelpers = {
    notifications: [
        {
            id: 'id',
            title: 'Mail 5',
            lastTime: '23 Minutes ago',
            state: 'state'
        },
        {
            id: 'id',
            title: 'Mail 5',
            lastTime: '23 Minutes ago',
            state: 'state'
        },
        {
            id: 'id',
            title: 'Mail 5',
            lastTime: '23 Minutes ago',
            state: 'state'
        },
    ],

    currentUser: {
        photoURL: 'assets/images/avatars/noavatar.png',
        currentUserName: 'Guest'
    }
};
