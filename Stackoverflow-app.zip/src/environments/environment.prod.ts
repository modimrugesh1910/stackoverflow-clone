export const environment = {
  production: false,
  apiBaseUrl: 'newproject.firebaseapp.com',
  firebase: {
    apiKey: '',
    authDomain: 'newproject.firebaseapp.com',
    databaseURL: '',
    projectId: 'newproject',
    storageBucket: 'newproject.appspot.com',
    messagingSenderId: ''
  },
  mailApi: '/assets/list.json'
};
